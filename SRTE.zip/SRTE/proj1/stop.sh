#!/bin/bash

# Virtual Network Topology for SRTE Testing 0.1
# based on Quagga and iproute2
# Last Modified @ 2020-0913

# Permission Verify
if [[ $(id -u) -ne 0 ]] ; then echo "Please run with sudo" ; exit 1 ; fi

function delete_network()
{
    ip netns exec s1 ./s1/stop.sh
    ip netns exec s2 ./s2/stop.sh
    ip netns exec s3 ./s3/stop.sh

    ip netns del s1
    ip netns del s2
    ip netns del s3
    ip netns del h1
    ip netns del h2
}

delete_network