#!/bin/bash
# Router Settings, run with s3 network namespace

# Start Loopback
ip link set lo up

# IPv6 Forwarding
sysctl net.ipv6.conf.all.forwarding=1
sysctl net.ipv6.conf.all.seg6_enabled=1
sysctl net.ipv6.conf.s3s1.seg6_enabled=1
sysctl net.ipv6.conf.s3s2.seg6_enabled=1    

# Default Routing Settings / NONE

# Launch Quagga/OSPF
ip route flush proto zebra
zebra -d -A 127.0.0.1 -f s3/zebra.conf -i s3/run/zebra.pid -z s3/run/zserv.api
ospf6d -d -A ::1 -f s3/ospf6d.conf -i s3/run/ospf6d.pid -z s3/run/zserv.api