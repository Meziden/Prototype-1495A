pkill -F run/zebra.pid
pkill -F run/ospf6d.pid
rm -rf run/zebra.pid
rm -rf run/ospf6d.pid
rm -rf run/zserv.api