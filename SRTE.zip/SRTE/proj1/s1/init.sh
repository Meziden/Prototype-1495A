#!/bin/bash
# Router Settings, run with s1 network namespace

# Start Loopback
echo "[s1/init] starting lo"
ip link set lo up

# IPv6 Forwarding
echo "[s1/init] setting up ipv6 forwarding parameters"
sysctl net.ipv6.conf.all.forwarding=1
sysctl net.ipv6.conf.all.seg6_enabled=1
sysctl net.ipv6.conf.s1s3.seg6_enabled=1
sysctl net.ipv6.conf.s1s2.seg6_enabled=1

# Default Routing Settings
echo "[s1/init] setting up default route"
ip -6 route add fc00:0002::0001/128 encap seg6 mode encap segs fc00:000c::0001 dev s1s3

# Launch Quagga/OSPF
echo "[s1/init] setting up quagga, ospf6d"
ip route flush proto zebra
zebra -d -A 127.0.0.1 -f s1/zebra.conf -i s1/run/zebra.pid -z s1/run/zserv.api
ospf6d -d -A ::1 -f s1/ospf6d.conf -i s1/run/ospf6d.pid -z s1/run/zserv.api