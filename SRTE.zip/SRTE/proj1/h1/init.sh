#!/bin/bash
# Host Settings, run with h1 network namespace

# Loopback Settings
ip link set lo up

# Default Gateway Settings
ip addr add fc00:0001::0001/64 dev h1s1
ip link set dev h1s1 up  
ip -6 route add default via fc00:000a::0001