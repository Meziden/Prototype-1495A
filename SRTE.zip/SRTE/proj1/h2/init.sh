#!/bin/bash
# Host Settings, run with h2 network namespace

# Loopback Settings
ip link set lo up
ip link set h2s2 up        

# Default Gateway Settings
ip addr add fc00:0002::0001/64 dev h2s2
ip -6 route add default via fc00:000b::0001
