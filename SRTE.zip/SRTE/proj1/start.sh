#!/bin/bash

# Virtual Network Topology for SRTE Testing 0.1
# based on Quagga and iproute2
# Last Modified @ 2020-0913

# Address Definition
# Host1:        fc00:0001::/64
# Host2:        fc00:0002::/64
# Satellite1:   fc00:000a::/64
# Satellite2:   fc00:000b::/64
# Satellite3:   fc00:000c::/64

# Permission Verify
if [[ $(id -u) -ne 0 ]] ; then echo "Please run with sudo" ; exit 1 ; fi

function create_network()
{
    echo "[start.sh] creating namespaces."
    # Create Namespaces
    ip netns add h1
    ip netns add h2
    ip netns add s1
    ip netns add s2
    ip netns add s3

    echo "[start.sh] creating links."
    # Create Links
    ip link add name h1s1 type veth peer name s1h1 
    ip link add name h2s2 type veth peer name s2h2

    ip link add name s1s2 type veth peer name s2s1
    ip link add name s1s3 type veth peer name s3s1
    ip link add name s2s3 type veth peer name s3s2

    echo "[start.sh] connecting veth with namespaces."
    # Set Namespaces
    ip link set h1s1 netns h1
    ip link set h2s2 netns h2
    
    ip link set s1h1 netns s1
    ip link set s1s2 netns s1
    ip link set s1s3 netns s1

    ip link set s2h2 netns s2
    ip link set s2s1 netns s2
    ip link set s2s3 netns s2

    ip link set s3s1 netns s3
    ip link set s3s2 netns s3

    # Host and Router Settings
    echo "[start.sh] starting veth and routers."
    ip netns exec h1 ip link set h1s1 up
    ip netns exec h2 ip link set h2s2 up

    ip netns exec s1 ip link set s1h1 up
    ip netns exec s1 ip link set s1s2 up
    ip netns exec s1 ip link set s1s3 up

    ip netns exec s2 ip link set s2h2 up
    ip netns exec s2 ip link set s2s1 up
    ip netns exec s2 ip link set s2s3 up

    ip netns exec s3 ip link set s3s1 up
    ip netns exec s3 ip link set s3s2 up

    ip netns exec h1 ./h1/init.sh
    ip netns exec h2 ./h2/init.sh
    ip netns exec s1 ./s1/init.sh
    ip netns exec s2 ./s2/init.sh
    ip netns exec s3 ./s3/init.sh

    # Done
}

create_network