#!/bin/bash
# Router Settings, run with s2 network namespace

# Start Loopback
ip link set lo up

# IPv6 Forwarding
sysctl net.ipv6.conf.all.forwarding=1
sysctl net.ipv6.conf.all.seg6_enabled=1
sysctl net.ipv6.conf.s2s3.seg6_enabled=1
sysctl net.ipv6.conf.s2s1.seg6_enabled=1    

# Default Routing Settings
ip -6 route add fc00:0001::0001/128 encap seg6 mode encap segs fc00:000c::0002 dev s2s3

# Launch Quagga/OSPF
ip route flush proto zebra
zebra -d -A 127.0.0.1 -f s2/zebra.conf -i s2/run/zebra.pid -z s2/run/zserv.api
ospf6d -d -A ::1 -f s2/ospf6d.conf -i s2/run/ospf6d.pid -z s2/run/zserv.api